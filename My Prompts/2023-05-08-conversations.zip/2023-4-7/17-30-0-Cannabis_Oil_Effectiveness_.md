## USER
Hi, I have been prescribed medical cannabis in the UK. I am trying this in oil form as I don't smoke or vape. The prescription is as follows:

Adven Indica 20mg per ml:
THC - 10mg/ml
CBD - 10mg/ml
Take 0.2 to 1ml sublingually

However, I don't think it's having much effect, I've written some rough notes. Would you be able to organise them please so that I can show the doctor, thanks:

20230405
0.2ml under tongue at 22.30pm

This tastes and smells quite strong
Probably need to check whether other people can smell it
Wasn't too bad putting 0.2ml under tongue

Very tired as been back and forth to London for work over last two weeks

Just a quick test but I feel calm, level headed, ready for sleep at 23.10

----------------------

20230406

8am I'm on early shift so will take at 9am

9am 0.2ml under tongue

10.30 not sure if it's taken any effect yet

12.00 not sure 0.2ml of this is very effective, felt mild improvement but not compared to usual

12.30 0.3ml under tongue

This will be unaffordable because at this rate, it feels as though it will require several ml's a day

9pm 1ml under tongue
At best at this dose, if this works 1ml x times per day
44 pounds for 10ml
4.40 a day minimum
132 a month plus?

1ml is kinda gross to take as well

----------------------

20230407

2PM 1ml in drink, because I would like to see if consumption vs under tongue has any benefits and this would be preferable to under tongue.

4PM feel a little bit calmer? 


5PM, doesn't feel as though this has been effective.

## ASSISTANT
Sure, here is a summary of your notes that you can share with your doctor:

Date: 2023-04-05
- Took 0.2ml under tongue at 22:30 pm.
- Noticed a strong taste and smell, may need to check if others can smell it.
- Wasn't too difficult to take under the tongue.
- Felt calm, level-headed, and ready for sleep at 23:10.

Date: 2023-04-06
- Took 0.2ml under tongue at 9:00 am.
- Didn't feel any noticeable effect by 10:30 am.
- Felt a mild improvement by 12:00 pm, but not compared to usual.
- Took 0.3ml under tongue at 12:30 pm.
- Worried about the cost as it may require several ml's a day.
- Took 1ml under tongue at 9:00 pm, but found it difficult to take.
- Estimated cost to be 4.40 a day minimum, and 132 a month plus.

Date: 2023-04-07
- Took 1ml in drink at 2:00 pm to see if consumption vs under tongue has any benefits.
- Felt a little bit calmer by 4:00 pm.
- By 5:00 pm, it didn't feel as though the cannabis had been effective.

You may want to discuss with your doctor the frequency and dosage of the cannabis oil, as well as other administration methods. Additionally, it may be helpful to discuss any concerns you have about the cost and effectiveness of the current treatment plan.
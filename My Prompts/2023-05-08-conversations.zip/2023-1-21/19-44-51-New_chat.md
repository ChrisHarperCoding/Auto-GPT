## USER
Would it be possible to produce outputs for an example cad drawing for each section of a drum kit double bass pedal?
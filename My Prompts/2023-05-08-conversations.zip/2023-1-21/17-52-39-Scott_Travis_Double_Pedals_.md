## USER
What are Scott Travis' favourite double pedals please?

## ASSISTANT
I am not able to find any information about Scott Travis' favorite double pedals. Scott Travis is a musician and drummer, best known for his work as the drummer for Judas Priest. He may have a preference for certain double pedals, but it is not widely reported.


## USER
What pedals does he use then please?

## ASSISTANT
I couldn't find a specific information about what pedals Scott Travis currently uses. However, as a drummer, he may use a variety of different pedals depending on the type of music he is playing and the sound he is trying to achieve. Some common types of pedals used by drummers include bass drum pedals, hi-hat pedals, and snare drum pedals. Additionally, many drummers use electronic drum pads and triggers to enhance their sound or to trigger samples and other sounds.

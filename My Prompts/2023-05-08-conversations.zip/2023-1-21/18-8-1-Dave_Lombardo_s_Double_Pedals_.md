## USER
What are Dave Lombardo's favourite double bass pedals please?

## ASSISTANT
I'm sorry, I don't have any information on Dave Lombardo's favorite double bass pedals. However, Dave Lombardo is a drummer and is known for his use of double bass drum techniques. Some popular double bass pedals that are used by drummers include the Tama Iron Cobra, the Pearl Demon Drive, and the DW 9000 Series.

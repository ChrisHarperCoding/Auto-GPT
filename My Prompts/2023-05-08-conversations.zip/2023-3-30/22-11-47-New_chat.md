## USER
Hi, could you please help me to write you a prompt that would allow me to create an application?

## ASSISTANT
Sure, I can help
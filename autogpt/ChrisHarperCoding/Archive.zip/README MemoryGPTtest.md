# Destiny 2 App

This is a project to create a Destiny 2 app to track character progress.

import os

os.system('pip install pinterest-api')
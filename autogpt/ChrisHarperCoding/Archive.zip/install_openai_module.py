import subprocess
subprocess.run(['pip', 'install', 'openai'])
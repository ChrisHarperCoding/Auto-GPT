#!/bin/bash
python3 /workspace/search_file_v2.py /Users/chris/Documents/Obsidian\ Vault/Personal/20230324/ 2023-05-05.md
import subprocess

subprocess.run(['git', 'init'])
